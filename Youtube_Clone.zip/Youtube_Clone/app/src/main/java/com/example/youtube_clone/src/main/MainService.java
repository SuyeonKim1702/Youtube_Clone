package com.example.youtube_clone.src.main;

import com.example.youtube_clone.src.main.interfaces.MainActivityView;

class MainService {
    private final MainActivityView mMainActivityView;

    MainService(final MainActivityView mainActivityView) {
        this.mMainActivityView = mainActivityView;
    }




}
